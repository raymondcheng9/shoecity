<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{paypalusa}prestashop>configuration-mx_e23a427731b5843e02c2eea2caef1033'] = 'PayPal es la solución lider para aceptar pagos en línea';
$_MODULE['<{paypalusa}prestashop>configuration-mx_8928ebd47f4035fb8369b37ea94e526e'] = 'Si aún no tiene una cuenta de PayPal';
$_MODULE['<{paypalusa}prestashop>configuration-mx_2bc6b866ceb08e0d6ee821590089acbd'] = 'Clic aquí para crear una cuenta de PayPal';
$_MODULE['<{paypalusa}prestashop>configuration-mx_0c6755da915b75e43e9cfdf1f0382e82'] = 'Tarjetas de crédito y débito';
$_MODULE['<{paypalusa}prestashop>configuration-mx_6773d9ad0775fdeb88ccd15b79921626'] = 'Con PayPal puede aceptar las principales tarjetas de crédito y débito. PayPal le facilita también aceptar pagos en 25 divisas de 190 países.';
$_MODULE['<{paypalusa}prestashop>configuration-mx_b2af322501aa9172d8e1aa5cfe61776c'] = 'Ofrezca mensualidades';
$_MODULE['<{paypalusa}prestashop>configuration-mx_b89862467b572ae67c66f4fe8246c8ab'] = 'Brinde a sus clientes la oportunidad de pagarte en mensualidades con tarjetas de crédito: Bancomer, Banamex, HSBC, Santander y Banorte.';
$_MODULE['<{paypalusa}prestashop>configuration-mx_84f2eca4896b90e32a493437f202da1b'] = 'Configuración de API para Express Checkout Shortcut';
$_MODULE['<{paypalusa}prestashop>configuration-mx_650be61892bf690026089544abbd9d26'] = 'Modo';
$_MODULE['<{paypalusa}prestashop>configuration-mx_955ad3298db330b5ee880c2c9e6f23a0'] = 'En Vivo';
$_MODULE['<{paypalusa}prestashop>configuration-mx_6bb8a2eb94c85345047beb5719d7f090'] = 'Prueba (Sandbox)';
$_MODULE['<{paypalusa}prestashop>configuration-mx_4cd9dd643cd8d0c57bbf7e8a4e7c2380'] = 'Para obtener sus credenciales API de PayPal use los siguientes links:';
$_MODULE['<{paypalusa}prestashop>configuration-mx_0a8aa07844e785bc925b31a416f48940'] = 'API Modo en Vivo';
$_MODULE['<{paypalusa}prestashop>configuration-mx_ada9c8c0c9d77158b55ef390bf3f0f7f'] = 'API Modo Sandbox';
$_MODULE['<{paypalusa}prestashop>configuration-mx_20b5fa652d9e71b59cfb897052f44e82'] = 'PayPal Cuenta de Negocios';
$_MODULE['<{paypalusa}prestashop>configuration-mx_7dbc60e6ad9979ae7a525ea5fbd61cd4'] = 'Usuario API de PayPal';
$_MODULE['<{paypalusa}prestashop>configuration-mx_419045dfacceb6378c54aec795fd6949'] = 'Contraseña API de PayPal';
$_MODULE['<{paypalusa}prestashop>configuration-mx_023a7a87fa70d6890f099c6a754d5fe5'] = 'Firma APi de PayPal';
$_MODULE['<{paypalusa}prestashop>configuration-mx_7491fd8a2cb8d1ad74c94cd46e2dacb0'] = 'Configuración de botones para Express Checkout Shortcut';
$_MODULE['<{paypalusa}prestashop>configuration-mx_0ecfbf565a01ac6ac11f20daf39e6168'] = 'Mostrar el botón en';
$_MODULE['<{paypalusa}prestashop>configuration-mx_eb763a2e313718f33f55e1f0d84df6ee'] = 'Página de producto';
$_MODULE['<{paypalusa}prestashop>configuration-mx_b75443a19207ed3a3552edda86536857'] = 'Carrito de compras';
$_MODULE['<{paypalusa}prestashop>configuration-mx_a5a86f2a08ae606d44ed7af31e883d2a'] = 'Color del borde del botón';
$_MODULE['<{paypalusa}prestashop>configuration-mx_d4dccb8ca2dac4e53c01bd9954755332'] = 'Guardar Configuración';
$_MODULE['<{paypalusa}prestashop>configuration-mx_70397c4b252a5168c5ec003931cea215'] = 'Campos obligatorios';
$_MODULE['<{paypalusa}prestashop>configuration-mx_d3d2e617335f08df83599665eef8a418'] = 'Cerrar';
